How to Use this Bot

first go to the bin folder, then you click on the bot.exe, and your done!

you can make a short cut for this if you want

when you want to stop the bot, close the browser and control panel

this could be ran over night, but microsoft rewards has a limit from 200-500 point per day

!!! MAKE SURE TO HAVE A MICROSOFT ACCOUNT !!!

-----------Romine------------