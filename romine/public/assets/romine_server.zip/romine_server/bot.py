from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from wonderwords import RandomWord

driver = webdriver.Edge()
driver.get('https://www.bing.com/search?q=initiating&FORM=AWRE')

def random_letter():
    word = RandomWord().word()
    return "what does " + word + " mean?"

def run_bot():
    while True:
        search_box = driver.find_element("id", 'sb_form_q')
        search_box.click()
        search_box.send_keys(Keys.CONTROL + 'a')
        search_box.send_keys(Keys.BACKSPACE)
        search_box.send_keys(random_letter())
        search_box.send_keys(Keys.RETURN)
        time.sleep(5)

run_bot()